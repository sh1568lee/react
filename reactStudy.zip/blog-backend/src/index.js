require('dotenv').config();
const mongoose = require('mongoose');
const session = require('koa-session');
const ssr = require('./ssr');
const path = require('path');
const serve = require('koa-static');

const staticPath = path.join(__dirname, '../../blog-frontend/build');

const {
    PORT: port = 4000,
    MONGO_URI: mongoURI,
    COOKIE_SIGN_KEY: signKey
} = process.env;

mongoose.Promise = global.Promise;

mongoose.connect(mongoURI).then(() => {
    console.log('connected to mongodb');
}).catch((e) => {
    console.error(e);
})

const Koa = require('koa');
const Router = require('koa-router');

const bodyParser = require('koa-bodyparser');


const api = require('./api');

const app = new Koa();
const router = new Router();

// router 적용 전에 먼저 body parser적용.
app.use(bodyParser());

router.use('/api', api.routes());
router.get('/', ssr);


const sessionConfig = {
    masAge: 86400000 // 하루
    // signed: true (기본으로 설정됨.))
}

app.use(session(sessionConfig, app));
app.keys = [signKey];
app.use(router.routes()).use(router.allowedMethods());
app.use(serve(staticPath));
app.use(ssr);

app.listen(port, ()=>{
    console.log('listening to port ' + port);
})


