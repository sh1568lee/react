const { ADMIN_PASS: adminPass } = process.env;

exports.login = (ctx) => {
    const { password } = ctx.request.body;
    if (adminPass === password) {
        ctx.body = {
            success: true
        };
        ctx.session.logged = true;
    } else {
        ctx.body = {
            sucess: false
        };
        ctx.status = 401; // Unauthorized 
    }
}

exports.check = (ctx) => {
    ctx.body = {
        // ! 문자를 두 번 입력하여
        // 값이 존재하지 않을때도 false를 반환하도록 설정
        logged: !!ctx.session.logged
    };
};

exports.logout = (ctx) => {
    ctx.session = null;
    ctx.status = 204; // no contents;
}

// 세션 값을 설정할때는 ctx.session.이름 = 값
// 조회할떄는 tx.session.이름
// 세션을 파기시에는 ctx.session =null;