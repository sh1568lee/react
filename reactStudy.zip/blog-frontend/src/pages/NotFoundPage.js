import React from 'react';
import NotFound from 'components/common/NotFound';

const NotFoundPage = ({history, staticContext}) => {
    // 리액트 라우터가 전달하는 history  staticContext를 받아온다.
    // staticContext는 서버 러ㅔㄴ더링을 하는 StaticRouter를 사용할때만 존재하는 객체
    // 웹브라우저에서는 존재하지 않는다. fpsejfldgn 서버에 특정정보를 전달해야할때 사용.
    if (staticContext) {
        staticContext.isNotFound = true;
    }
    return (
        <NotFound onGoBack={history.goBack}/>
    )
}

export default NotFoundPage;