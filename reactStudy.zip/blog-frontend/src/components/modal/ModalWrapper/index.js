import ModalWrapper from './ModalWrapper';

export default ModalWrapper;
