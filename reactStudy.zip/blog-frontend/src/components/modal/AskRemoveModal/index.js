import AskRemoveModal from './AskRemoveModal';

export default AskRemoveModal;
