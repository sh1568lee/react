import React, { Component } from 'react';
import styles from './MarkdownRender.scss';
import classNames from 'classnames/bind';

import marked from 'marked';

import Prism from 'prismjs';
import 'prismjs/themes/prism-okaidia.css';
import { isBoolean } from 'util';

// import 'prismjs/components/prism-bash.min.js';
// import 'prismjs/components/prism-javascript.min.js';
// import 'prismjs/components/prism-jsx.min.js';
// import 'prismjs/components/prism-css.min.js';

const isBrowser = process.env.APP_ENV === 'browser';
if (isBrowser) {
    require('prismjs/components/prism-bash.min.js');
    require('prismjs/components/prism-javascript.min.js');
    require('prismjs/components/prism-jsx.min.js');
    require('prismjs/components/prism-css.min.js');
}

const cx = classNames.bind(styles);

class MarkdownRender extends Component {
    state = {
        html: ''
    }

    renderMarkdown = () => {
        const { markdown } = this.props;
        console.log('MarkDownRender markdown ' + markdown)

        if(!markdown) {
            this.setState({
                html: ''
            })
            return;
        }
        this.setState({
            html: marked(markdown, {
                breaks: true, // 일반 엔터로 새 줄 입력
                sanitize: true // 마크다운 내부 html 무시  
            })
        });
    }

    constructor(props) {
        super(props);
        const { markdown } = this.props;
        console.log('MarkDownRender constcructor : ' + markdown)
        // 서버 사이드 렌더링에서도 마크다운 처리가 되도록 consturctor 쪽에서도 구현합니다.
        this.setState({
            html: markdown ? marked(props.markdown, {breaks:true, sanitize: true}) : ''
        });
    }

    shouldComponentUpdate(nextProps, nextState) {
        console.log('markdownRender shouldComponentUpdate')
        // if (nextProps.markdown !== this.props.markdown) {
        //     this.renderMarkdown();
        //     return true;
        // }
        
        // if (nextState.html !== this.state.html) {
        //     Prism.highlightAll();
        //     return true;
        // }       
        return true;
    }

    componentDidUpdate(prevProps, prevState) {
        console.log('componentDidUpdate markdown ' + prevProps.markdown + ', ' + this.props.markdown)

        // // markdown 값이 변경되면 renderMarkdown을 호출합니다.
        if (prevProps.markdown !== this.props.markdown) {
            this.renderMarkdown();
        }
        
        if (prevState.html !== this.state.html) {
            Prism.highlightAll();
        }
    }

    componentDidMount() {
        this.renderMarkdown();
        Prism.highlightAll();
    }

    render() {
        const { html } = this.state;

        // React에서 html을 렌더링하려면 객체를 만들어 내부에 __html값을 설정해야함.
        const markup = {
            __html: html
        }
        // dangerouslySetInnerHTML 값에 해당 객체를 넣어준다.
        return (
            <div className={cx('markdown-render')} dangerouslySetInnerHTML={markup}/>
        )
    }
}
// constructor함수는 서버 사이드 렌더링을 할 때도 호출한다.
// 이 작업을 didmount에서 한다면 웹브라우저쪽에서만 실행하고 서버 쪽에서는 호출 x

export default MarkdownRender;


// # h1
// ## h2
// ### h3
// #### h4
// ##### h5 
// > blockquote
// ```javascript
// console.log('Code');
// ```
// `코드` 텍스트 사이
// [링크](https://google.com)
// ## Image
// ![](http://via.placeholder.com/350x150)
