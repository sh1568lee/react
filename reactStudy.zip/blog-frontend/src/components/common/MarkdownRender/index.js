import MarkdownRender from './MarkdownRender';

export default MarkdownRender;
