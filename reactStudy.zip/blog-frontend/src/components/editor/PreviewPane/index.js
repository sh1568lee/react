import PreviewPane from './PreviewPane';

export default PreviewPane;
