import EditorPane from './EditorPane';

export default EditorPane;
