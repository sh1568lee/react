import EditorTemplate from './EditorTemplate';

export default EditorTemplate;
