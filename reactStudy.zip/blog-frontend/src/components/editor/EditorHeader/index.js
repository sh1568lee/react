import EditorHeader from './EditorHeader';

export default EditorHeader;
