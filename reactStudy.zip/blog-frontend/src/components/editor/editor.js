import React from 'react';
import cssModule from 'react-css-modules';
import styles from './editor.css';

class editor extends React.Component {
  static propTypes = {

  }
  render = () => (
    <div>
      editor
    </div>
  )
}

export default cssModule(editor, styles);
