import editor from './editor';

export default editor;
