import PostInfo from './PostInfo';

export default PostInfo;
