import PostList from './PostList';

export default PostList;
